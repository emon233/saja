Best wishes,  
Professor Dr. S.A. Kamal Uddin Khan  
Executive Editor  
South Asian Journal of Agriculture (SAJA)  
Agrotechnology Discipline, Khulna University  
Khulna-9208, Bangladesh  
  
Email: info@saja.edu.bd; executive.editor@saja.edu.bd